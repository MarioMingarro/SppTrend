utils::globalVariables(
  c("species", "hemisphere", "n", "Spatial_lat_Poleward",
    "Spatial_lon", "Spatial_ele", "Thermal_tmx", "Thermal_tmn",
    "Thermal_tme")
)
