## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## -----------------------------------------------------------------------------
# Install the development version from CRAN or GitHub
# install.packages("SppTrend")
# devtools::install_github("MarioMingarro/SppTrend")

library(SppTrend)
library(knitr)
library(DT)
library(ggplot2)
library(rnaturalearth)
library(sf)
library(readr)

## ----echo = FALSE-------------------------------------------------------------
path_to_file <- system.file("extdata", "example_ranidae.csv", package = "SppTrend")
if (path_to_file == "") {
  path_to_file <- "../inst/extdata/example_ranidae.CSV"
}

## ----eval=FALSE---------------------------------------------------------------
#  path_to_file <- "PERSONAL/PATH/TO/DATA"

## -----------------------------------------------------------------------------
ranidae <- read_csv2(path_to_file, 
                    col_types = cols(year = col_double(),
                                     month = col_double(),
                                     lon = col_double(),
                                     lat = col_double()))

## -----------------------------------------------------------------------------
# Construct a continuous temporal predictor combining year and month
ranidae$year_month <- ranidae$year + (ranidae$month * 0.075)

## ----echo = FALSE-------------------------------------------------------------
DT::datatable(ranidae, caption = "Table 1: Initial dataset structure.", options = list(scrollX = TRUE)) 

## ----eval = FALSE-------------------------------------------------------------
#  ranidae <- get_era5_tme(data = ranidae,
#                                 nc_file = "personal/path/era5_land.nc")

## ----eval = FALSE-------------------------------------------------------------
#  ranidae <- extract_elevation(data = ranidae,
#                                      dem_file = "personal/path/dem_wc21_30s.tif")

## ----include = FALSE----------------------------------------------------------
path_to_file <- system.file("extdata", "example_ranidae_tme_ele.csv", package = "SppTrend")
if (path_to_file == "") {
  path_to_file <- "../inst/extdata/example_ranidae_tme_ele.csv"
}

ranidae <- read_csv2(path_to_file, 
                    col_types = cols(year = col_double(),
                                     month = col_double(),
                                     lon = col_double(),
                                     lat = col_double(),
                                     year_month = col_double(),
                                     tme = col_double(),
                                     ele = col_double()))

## ----echo = FALSE-------------------------------------------------------------
DT::datatable(ranidae, caption = "Table 2: Data with environmental variables.", options = list(scrollX = TRUE))

## -----------------------------------------------------------------------------
predictor <- "year_month"

responses <- c("lat", "lon", "ele", "tme")

species_list <- unique(ranidae$species)

ranidae <- na.omit(ranidae)

## -----------------------------------------------------------------------------
overall_res <- overall_trend(ranidae, predictor = predictor, responses = responses)

## ----echo = FALSE-------------------------------------------------------------
DT::datatable(overall_res, caption = "Table 3: Aggregate trends for all observations.", options = list(scrollX = TRUE))

## -----------------------------------------------------------------------------
spp_res <- spp_trend(ranidae, species_list, 
                     predictor = predictor, 
                     responses = responses, 
                     n_min = 5)

## -----------------------------------------------------------------------------
strategy_res <- spp_strategy(spp_res, 
                             sig_level = 0.05, 
                             responses = c("lat", "lon", "tme", "ele"))

## ----echo = FALSE-------------------------------------------------------------
DT::datatable(strategy_res, caption = "Table 4: Classification of biological strategies.", options = list(scrollX = TRUE))

## -----------------------------------------------------------------------------
example_spp <- "Lithobates sylvaticus"
viz_data <- ranidae[ranidae$species == example_spp, ]

## ----fig.width=12, fig.height=8, out.width="100%"-----------------------------
world_map <- ne_countries(scale = "medium", returnclass = "sf")
ggplot() +
  geom_sf(data = world_map, fill = "#f9f9f9", color = "grey80") +
  geom_point(data = viz_data, aes(x = lon, y = lat, col = year), alpha = 0.6, size = 2) +
  scale_colour_viridis_c(option = "viridis", name = "Year") +
  labs(title = paste("Distribution of", example_spp),
       subtitle = paste("Total records:", nrow(viz_data)),
       x = "Longitude", y = "Latitude") +
  theme_minimal() +
  theme(axis.text = element_text(size = 8),
        legend.position = "bottom")

## ----fig.width=12, fig.height=8, out.width="100%"-----------------------------
ggplot() +
  geom_point(data = ranidae, aes(x = year_month, y = lat), color = "grey80", alpha = 0.3) + 
  geom_smooth(data = ranidae, aes(x = year_month, y = lat), 
              method = "lm", color = "black", linetype = "dashed", se = FALSE) +
  geom_smooth(data = viz_data, aes(x = year_month, y = lat), 
              method = "lm", color = "red", fill = "red", alpha = 0.2) +
  labs(title = paste("Latitudinal trend:", example_spp),
       subtitle = "SE",
       x = "Date", y = "Latitude") +
  theme_minimal()

## ----fig.width=12, fig.height=8, out.width="100%"-----------------------------
example_spp <- "Pelophylax nigromaculatus"
viz_data <- ranidae[ranidae$species == example_spp, ]
ggplot() +
  geom_point(data = ranidae, aes(x = year_month, y = tme), color = "grey80", alpha = 0.3) + 
  geom_smooth(data = ranidae, aes(x = year_month, y = tme), 
              method = "lm", color = "black", linetype = "dashed", se = FALSE) +
  geom_smooth(data = viz_data, aes(x = year_month, y = tme), 
              method = "lm", color = "red", fill = "red", alpha = 0.2) +
  labs(title = paste("Temperature trend:", example_spp),
       subtitle = "TT",
       x = "Date", y = "Temperature (ºC)") +
  theme_minimal()

## ----fig.width=12, fig.height=8, out.width="100%"-----------------------------
example_spp <- "Lithobates pipiens"
viz_data <- ranidae[ranidae$species == example_spp, ]
ggplot() +
  geom_point(data = ranidae, aes(x = year_month, y = ele), color = "grey80", alpha = 0.3) + 
  geom_smooth(data = ranidae, aes(x = year_month, y = ele), 
              method = "lm", color = "black", linetype = "dashed", se = FALSE) +
  geom_smooth(data = viz_data, aes(x = year_month, y = ele), 
              method = "lm", color = "red", fill = "red", alpha = 0.2) +
  labs(title = paste("Elevation trend:", example_spp),
       subtitle = "SD",
       x = "Date", y = "Elevation (m)") +
  theme_minimal()

